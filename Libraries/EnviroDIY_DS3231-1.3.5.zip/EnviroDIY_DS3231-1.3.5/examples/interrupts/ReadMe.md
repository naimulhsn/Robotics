This example demonstrates the use of interrupts for battery management/saving using MCU power down mode.
