This example sends the current date and time to the serial port every second at 57600 baud.
